/**
 * YouTube Channel Crawler
 * Premium Edition JS
 */

// API Test module
const APITester = {
    init() {
        this.testBtn = document.getElementById('api-test-btn');
        this.resultContainer = document.getElementById('api-test-result');
        this.keyInput = document.getElementById('api_key');
        this.setupEventListeners();
    },

    setupEventListeners() {
        if (this.testBtn) {
            this.testBtn.addEventListener('click', () => this.testAPIKey());
        }
    },

    testAPIKey() {
        const apiKey = this.keyInput.value.trim();
        if (!apiKey) {
            this.showResult('error', 'Please enter an API key to test');
            return;
        }

        this.testBtn.disabled = true;
        this.testBtn.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Testing...';
        
        fetch('/test-api-key', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ api_key: apiKey })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                this.showResult('success', data.message, data.quota_info);
            } else {
                this.showResult('error', data.message);
            }
        })
        .catch(error => {
            this.showResult('error', 'Network error occurred while testing API key');
            console.error('API test error:', error);
        })
        .finally(() => {
            this.testBtn.disabled = false;
            this.testBtn.innerHTML = 'Test API Key';
        });
    },

    showResult(type, message, quotaInfo = null) {
        let html = '';
        
        if (type === 'success') {
            html = `
                <div class="alert alert-success">
                    <i class="bi bi-check-circle-fill me-2"></i> ${message}
                </div>
            `;
            
            if (quotaInfo) {
                html += `
                    <div class="mt-3">
                        <h6>Quota Information:</h6>
                        <ul class="list-group">
                            <li class="list-group-item bg-dark text-white border-secondary">
                                Daily Limit: ${quotaInfo.limit}
                            </li>
                            <li class="list-group-item bg-dark text-white border-secondary">
                                Used Today: ${quotaInfo.used}
                            </li>
                            <li class="list-group-item bg-dark text-white border-secondary">
                                Remaining: ${quotaInfo.remaining}
                            </li>
                        </ul>
                    </div>
                `;
            }
        } else {
            html = `
                <div class="alert alert-danger">
                    <i class="bi bi-exclamation-triangle-fill me-2"></i> ${message}
                </div>
            `;
        }
        
        this.resultContainer.innerHTML = html;
        this.resultContainer.style.display = 'block';
    }
};

// Channel Crawler main module
const ChannelCrawler = {
    init() {
        this.form = document.getElementById('crawler-form');
        this.searchBtn = document.getElementById('search-btn');
        this.progressContainer = document.getElementById('progress-container');
        this.progressBar = document.getElementById('progress-bar');
        this.progressText = document.getElementById('progress-text');
        this.statusMessage = document.getElementById('status-message');
        this.errorMessage = document.getElementById('error-message');
        this.resultsContainer = document.getElementById('results-container');
        this.channelsGrid = document.getElementById('channels-grid');
        this.exportButtons = document.getElementById('export-options');
        this.loadingSpinner = document.getElementById('loading-spinner');
        this.channelCount = document.getElementById('channel-count');
        this.liveUpdateIndicator = document.getElementById('live-update-indicator');
        
        this.currentJobId = null;
        this.statusCheckInterval = null;
        this.channels = [];
        
        this.setupEventListeners();
        this.initializeDropdownFilters();
    },
    
    setupEventListeners() {
        if (this.form) {
            this.form.addEventListener('submit', (e) => {
                e.preventDefault();
                this.startCrawling();
            });
        }
        
        // Export button event listeners
        document.querySelectorAll('.export-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const format = e.target.dataset.format;
                this.exportResults(format);
            });
        });
        
        // Filter toggle event listeners
        document.getElementById('toggle-filters').addEventListener('click', () => {
            const filterContainer = document.getElementById('filter-container');
            filterContainer.classList.toggle('d-none');
            
            const icon = document.getElementById('toggle-filters-icon');
            if (filterContainer.classList.contains('d-none')) {
                icon.classList.remove('bi-chevron-up');
                icon.classList.add('bi-chevron-down');
            } else {
                icon.classList.remove('bi-chevron-down');
                icon.classList.add('bi-chevron-up');
            }
        });
    },
    
    initializeDropdownFilters() {
        // Initialize filter dropdowns with Select2
        if (typeof $.fn.select2 !== 'undefined') {
            $('.select2-dropdown').select2({
                theme: 'bootstrap-5',
                dropdownParent: $('.select2-dropdown').parent(),
                placeholder: 'Select options'
            });
        }
    },
    
    startCrawling() {
        // Reset UI
        this.errorMessage.style.display = 'none';
        this.resultsContainer.style.display = 'none';
        this.channelsGrid.innerHTML = '';
        this.channels = [];
        
        // Show progress
        this.progressContainer.style.display = 'block';
        this.progressBar.style.width = '0%';
        this.progressBar.setAttribute('aria-valuenow', 0);
        this.progressText.textContent = '0%';
        this.statusMessage.innerHTML = '<div class="spinner-border spinner-border-sm text-light me-2" role="status"></div> Initializing search...';
        this.liveUpdateIndicator.style.display = 'inline-block';
        
        // Disable form
        this.searchBtn.disabled = true;
        
        // Get form data
        const formData = new FormData(this.form);
        
        // Start crawling
        fetch('/scrape', {
            method: 'POST',
            body: formData
        })
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(data => {
            this.currentJobId = data.job_id;
            
            // Start checking status
            this.checkStatus();
            this.statusCheckInterval = setInterval(() => this.checkStatus(), 1000);
        })
        .catch(error => {
            console.error('Error:', error);
            this.errorMessage.textContent = `Error: ${error.message}`;
            this.errorMessage.style.display = 'block';
            this.liveUpdateIndicator.style.display = 'none';
            this.statusMessage.textContent = 'Error occurred';
            this.searchBtn.disabled = false;
        });
    },
    
    checkStatus() {
        if (!this.currentJobId) return;
        
        fetch(`/status/${this.currentJobId}`)
        .then(response => response.json())
        .then(data => {
            // Update progress
            this.progressBar.style.width = `${data.progress}%`;
            this.progressBar.setAttribute('aria-valuenow', data.progress);
            this.progressText.textContent = `${data.progress}%`;
            
            // Update status message based on state
            if (data.status === 'running') {
                this.statusMessage.innerHTML = '<div class="spinner-border spinner-border-sm text-light me-2" role="status"></div> Crawling YouTube channels...';
                
                // If we have partial results, update the channels grid
                if (data.partial_results && data.partial_results.length > 0) {
                    this.updateChannelsWithPartialResults(data.partial_results);
                }
            } else if (data.status === 'completed') {
                this.liveUpdateIndicator.style.display = 'none';
                this.statusMessage.innerHTML = '<i class="bi bi-check-circle-fill me-2"></i> Search completed!';
                clearInterval(this.statusCheckInterval);
                
                // Show full results
                this.displayFullResults(data);
                
                // Re-enable form
                this.searchBtn.disabled = false;
            } else if (data.status === 'error') {
                this.liveUpdateIndicator.style.display = 'none';
                this.statusMessage.innerHTML = '<i class="bi bi-exclamation-triangle-fill me-2"></i> Error occurred!';
                this.errorMessage.textContent = data.error || 'An unknown error occurred';
                this.errorMessage.style.display = 'block';
                clearInterval(this.statusCheckInterval);
                
                // If we have partial results, still show them
                if (data.partial_results && data.partial_results.length > 0) {
                    this.updateChannelsWithPartialResults(data.partial_results);
                    this.resultsContainer.style.display = 'block';
                }
                
                // Re-enable form
                this.searchBtn.disabled = false;
            }
        })
        .catch(error => {
            console.error('Error checking status:', error);
            clearInterval(this.statusCheckInterval);
            this.searchBtn.disabled = false;
            this.liveUpdateIndicator.style.display = 'none';
        });
    },
    
    updateChannelsWithPartialResults(partialResults) {
        // Add only new channels that aren't already in our list
        const newChannels = partialResults.filter(newChannel => 
            !this.channels.some(existingChannel => existingChannel.id === newChannel.id)
        );
        
        if (newChannels.length > 0) {
            this.channels = [...this.channels, ...newChannels];
            
            // Update the channel count
            if (this.channelCount) {
                this.channelCount.textContent = this.channels.length;
            }
            
            // Display results container if it's the first results
            if (this.channels.length > 0 && this.resultsContainer.style.display === 'none') {
                this.resultsContainer.style.display = 'block';
            }
            
            // Render new channels to grid
            newChannels.forEach(channel => {
                this.addChannelCard(channel);
            });
        }
    },
    
    displayFullResults(data) {
        // If we have full results, replace any partial results
        if (data.results && data.results.length > 0) {
            this.channels = data.results;
            
            // Update the channel count
            if (this.channelCount) {
                this.channelCount.textContent = this.channels.length;
            }
            
            // Clear the grid and repopulate
            this.channelsGrid.innerHTML = '';
            this.channels.forEach(channel => {
                this.addChannelCard(channel);
            });
        }
        
        // Show error if there is one, even with results
        if (data.error) {
            this.errorMessage.textContent = data.error;
            this.errorMessage.style.display = 'block';
        }
        
        // Show results container and enable export
        this.resultsContainer.style.display = 'block';
        this.exportButtons.classList.remove('d-none');
    },
    
    addChannelCard(channel) {
        // Create a formatted subscriber and view count
        const formatNumber = (num) => {
            if (num >= 1000000) {
                return (num / 1000000).toFixed(1) + 'M';
            } else if (num >= 1000) {
                return (num / 1000).toFixed(1) + 'K';
            } else {
                return num;
            }
        };
        
        // Format date
        const formatDate = (dateString) => {
            const date = new Date(dateString);
            return date.toLocaleDateString();
        };
        
        // Create the card HTML
        const cardHtml = `
            <div class="col-md-6 col-lg-4 mb-4">
                <div class="channel-card">
                    <div class="channel-thumbnail" style="background-color: var(--primary-color);">
                        <div class="p-3 text-center">
                            <i class="bi bi-youtube text-white" style="font-size: 64px;"></i>
                        </div>
                    </div>
                    <div class="channel-info">
                        <h5 class="channel-title">${channel.title}</h5>
                        <div class="channel-stats">
                            <div class="channel-stat">
                                <div class="stat-value">${formatNumber(channel.subscribers)}</div>
                                <div class="stat-label">Subscribers</div>
                            </div>
                            <div class="channel-stat">
                                <div class="stat-value">${formatNumber(channel.views)}</div>
                                <div class="stat-label">Views</div>
                            </div>
                            <div class="channel-stat">
                                <div class="stat-value">${channel.videos}</div>
                                <div class="stat-label">Videos</div>
                            </div>
                        </div>
                        <div class="d-flex justify-content-between align-items-center mt-3">
                            <span class="badge bg-secondary">${channel.country}</span>
                            <span class="text-secondary small">Since ${formatDate(channel.created_at)}</span>
                        </div>
                        <div class="mt-3">
                            <a href="https://youtube.com/channel/${channel.id}" target="_blank" class="btn btn-sm btn-danger">
                                <i class="bi bi-youtube me-1"></i> View Channel
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        `;
        
        // Add the card to the grid
        this.channelsGrid.insertAdjacentHTML('beforeend', cardHtml);
    },
    
    exportResults(format) {
        if (!this.channels || this.channels.length === 0) {
            alert('No data to export');
            return;
        }
        
        if (format === 'excel') {
            window.location.href = `/download/${this.currentJobId}`;
        } else if (format === 'csv') {
            window.location.href = `/download/${this.currentJobId}?format=csv`;
        } else if (format === 'json') {
            window.location.href = `/download/${this.currentJobId}?format=json`;
        }
    }
};

// When the document is ready, initialize our modules
document.addEventListener('DOMContentLoaded', function() {
    APITester.init();
    ChannelCrawler.init();
    
    // Initialize tooltips
    if (typeof bootstrap !== 'undefined') {
        const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
        tooltipTriggerList.map(function (tooltipTriggerEl) {
            return new bootstrap.Tooltip(tooltipTriggerEl);
        });
    }
}); 