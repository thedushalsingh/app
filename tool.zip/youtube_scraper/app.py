import os
import json
import time
import csv
import threading
import random
import requests
import socket
from datetime import datetime
from flask import Flask, render_template, request, jsonify, send_file, redirect, url_for, session, Response, flash
import pandas as pd
import googleapiclient.discovery
import googleapiclient.errors
import googleapiclient.http as google_http
import httplib2

# Import socks if available, otherwise provide fallback
try:
    import socks
except ImportError:
    # Define a simple fallback for proxy type if socks is not available
    class SocksProxy:
        PROXY_TYPE_HTTP = 3
    socks = SocksProxy()

app = Flask(__name__)
app.secret_key = "youtube_scraper_secret_key"
app.config['UPLOAD_FOLDER'] = 'results'

# Create results directory if it doesn't exist
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

# Default API key - may have reached quota limit
DEFAULT_API_KEY = "AIzaSyAnQL4nDQVwfRDVLMVlNma_obxF4slvKfs"
API_SERVICE_NAME = "youtube"
API_VERSION = "v3"

# Scraping job status
scraping_jobs = {}

# Proxy list - will be populated with free proxies if enabled
PROXY_LIST = []
PROXIES_ENABLED = True  # Set to True to enable proxy rotation
CURRENT_PROXY_INDEX = 0
MAX_RETRIES = 3  # Maximum number of retries per request

# Channel categories (video categories in YouTube API)
CATEGORIES = {
    "All": None,
    "Film & Animation": 1,
    "Autos & Vehicles": 2,
    "Music": 10,
    "Pets & Animals": 15,
    "Sports": 17,
    "Travel & Events": 19, 
    "Gaming": 20,
    "People & Blogs": 22,
    "Comedy": 23,
    "Entertainment": 24,
    "News & Politics": 25,
    "Howto & Style": 26,
    "Education": 27,
    "Science & Technology": 28,
    "Nonprofits & Activism": 29
}

# Common country codes
LOCATIONS = {
    "Worldwide": None,
    "United States": "US",
    "United Kingdom": "GB",
    "Canada": "CA",
    "Australia": "AU",
    "India": "IN",
    "Germany": "DE",
    "France": "FR",
    "Japan": "JP",
    "Brazil": "BR",
    "Russia": "RU",
    "South Korea": "KR",
    "Spain": "ES",
    "Italy": "IT",
    "Mexico": "MX",
    "Netherlands": "NL",
    "Sweden": "SE",
    "Other": "other"
}

# Languages available
LANGUAGES = {
    "Any Language": None,
    "English": "en",
    "Spanish": "es",
    "French": "fr",
    "German": "de",
    "Italian": "it",
    "Portuguese": "pt",
    "Russian": "ru",
    "Japanese": "ja",
    "Korean": "ko",
    "Chinese": "zh",
    "Arabic": "ar",
    "Hindi": "hi"
}

# Create a proxied HTTP object
class ProxiedHttp(httplib2.Http):
    def __init__(self, proxy_info=None, *args, **kwargs):
        super(ProxiedHttp, self).__init__(*args, **kwargs)
        self.proxy_info = proxy_info
        
    def _conn_request(self, conn, request_uri, method, body, headers):
        if self.proxy_info:
            conn.set_tunnel(request_uri.split('//', 1)[1].split('/', 1)[0], 
                           headers=headers)
        return super(ProxiedHttp, self)._conn_request(conn, request_uri, method, body, headers)

def fetch_free_proxies():
    """Fetch a list of free proxies from public sources"""
    proxies = []
    try:
        # Try to get free proxies from a public API
        print("Fetching free proxies...")
        try:
            response = requests.get('https://api.proxyscrape.com/v2/?request=getproxies&protocol=http&timeout=10000&country=all&ssl=all&anonymity=all', timeout=10)
            if response.status_code == 200:
                proxy_list = response.text.strip().split('\r\n')
                # Format proxies as http://ip:port
                proxies = [f"http://{proxy}" for proxy in proxy_list if proxy]
                print(f"Fetched {len(proxies)} proxies")
        except Exception as e:
            print(f"Error accessing primary proxy source: {str(e)}")
            
        # Try another source if we didn't get anything
        if not proxies:
            try:
                response = requests.get('https://raw.githubusercontent.com/TheSpeedX/PROXY-List/master/http.txt', timeout=10)
                if response.status_code == 200:
                    proxy_list = response.text.strip().split('\n')
                    proxies = [f"http://{proxy}" for proxy in proxy_list if proxy]
                    print(f"Fetched {len(proxies)} proxies from backup source")
            except Exception as e:
                print(f"Error accessing backup proxy source: {str(e)}")
            
        # If we couldn't get any proxies from the API, add some fallback proxies
        if not proxies:
            print("Using fallback proxy list")
            proxies = [
                "http://144.217.101.245:3129",
                "http://104.129.194.26:8800",
                "http://51.222.146.133:8080",
                "http://51.79.50.31:9300",
                "http://51.79.50.22:9300"
            ]
    except Exception as e:
        print(f"Error fetching proxies: {str(e)}")
        # Fallback to some proxy services
        proxies = [
            "http://144.217.101.245:3129",
            "http://104.129.194.26:8800",
            "http://51.222.146.133:8080",
            "http://51.79.50.31:9300",
            "http://51.79.50.22:9300"
        ]
    
    return proxies

def get_next_proxy():
    """Get the next proxy from the rotation list"""
    global CURRENT_PROXY_INDEX, PROXY_LIST
    
    # If proxy list is empty or we've used all proxies, refresh the list
    if not PROXY_LIST or CURRENT_PROXY_INDEX >= len(PROXY_LIST):
        PROXY_LIST = fetch_free_proxies()
        CURRENT_PROXY_INDEX = 0
        
    # If we still have no proxies, return None
    if not PROXY_LIST:
        return None
        
    # Get the next proxy
    proxy = PROXY_LIST[CURRENT_PROXY_INDEX]
    CURRENT_PROXY_INDEX = (CURRENT_PROXY_INDEX + 1) % len(PROXY_LIST)
    
    print(f"Using proxy: {proxy}")
    return proxy

def initialize_youtube_client(api_key, use_proxy=False):
    """Initialize the YouTube API client with optional proxy support"""
    try:
        if use_proxy and PROXIES_ENABLED:
            # Try to get a proxy from the list
            proxy_url = get_next_proxy()
            if proxy_url:
                print(f"Initializing YouTube client with proxy: {proxy_url}")
                
                try:
                    # Standard initialization without proxy - we'll handle proxying at the request level
                    youtube = googleapiclient.discovery.build(
                        API_SERVICE_NAME, 
                        API_VERSION, 
                        developerKey=api_key,
                        cache_discovery=False
                    )
                    
                    # Store the proxy information in the job - the app will display this
                    # but we can't actually use the proxy directly with the API client
                    # We'll use it in our retry logic instead
                    return youtube, proxy_url
                except Exception as e:
                    print(f"Error creating YouTube client with proxy: {str(e)}")
                    # Fall back to standard initialization
        
        # Standard initialization without proxy
        youtube = googleapiclient.discovery.build(
            API_SERVICE_NAME, 
            API_VERSION, 
            developerKey=api_key,
            cache_discovery=False
        )
        return youtube, None
    except Exception as e:
        print(f"Error initializing YouTube client: {str(e)}")
        raise

def execute_with_retry(request_func, max_retries=MAX_RETRIES):
    """Execute an API request with retry logic and proxy rotation on failure"""
    retry_count = 0
    last_error = None
    
    while retry_count < max_retries:
        try:
            return request_func()
        except googleapiclient.errors.HttpError as e:
            error_content = json.loads(e.content.decode())
            error_message = error_content.get('error', {}).get('message', str(e))
            
            # Don't retry quota errors - they won't be resolved with retries
            if "quota" in error_message.lower():
                raise
                
            print(f"API request failed (retry {retry_count+1}/{max_retries}): {error_message}")
            last_error = e
            retry_count += 1
            
            # Add exponential backoff
            if retry_count < max_retries:
                sleep_time = 2 ** retry_count  # 2, 4, 8, 16, ...
                print(f"Retrying in {sleep_time} seconds...")
                time.sleep(sleep_time)
        except Exception as e:
            print(f"Unexpected error (retry {retry_count+1}/{max_retries}): {str(e)}")
            last_error = e
            retry_count += 1
            
            # Add exponential backoff
            if retry_count < max_retries:
                sleep_time = 2 ** retry_count
                print(f"Retrying in {sleep_time} seconds...")
                time.sleep(sleep_time)
    
    # If we've exhausted all retries, raise the last error
    if last_error:
        raise last_error

def update_progress(job_id, progress, total_items=0, found_items=0, current_proxy=None, error=None):
    """Helper function to update job progress with consistent values"""
    # Calculate percentage progress capped at 100%
    percentage = min(int(progress), 100)
    
    # Update job status
    if job_id in scraping_jobs:
        scraping_jobs[job_id]['progress'] = percentage
        
        # Update current proxy if provided
        if current_proxy:
            scraping_jobs[job_id]['current_proxy'] = current_proxy
            
        # Update error if provided
        if error:
            scraping_jobs[job_id]['error'] = error
            
        # Print status update
        status_msg = f"Job {job_id}: {percentage}% complete"
        if total_items > 0:
            status_msg += f", processing item {found_items}/{total_items}"
        if current_proxy:
            status_msg += f" (via {current_proxy})"
        if error:
            status_msg += f" - ERROR: {error}"
            
        print(status_msg)

def scrape_youtube_channels(job_id, min_subs='', max_subs='', category='', location='', language='', upload_frequency='', api_key='', max_results=50, query=''):
    """Background thread function for scraping YouTube channels"""
    try:
        # Initialize job status and progress
        scraping_jobs[job_id]['status'] = 'running'
        update_progress(job_id, 5)  # Start with 5% progress to show initialization
        results = []
        
        print(f"Starting search with parameters: query={query}, min_subs={min_subs}, max_subs={max_subs}, category={category}, location={location}, language={language}, upload_frequency={upload_frequency}, max_results={max_results}")
        
        # Initialize YouTube API client
        try:
            youtube, current_proxy = initialize_youtube_client(api_key, use_proxy=PROXIES_ENABLED)
            update_progress(job_id, 10, current_proxy=current_proxy)  # 10% progress after initialization
        except Exception as e:
            error_msg = f"API client initialization error: {str(e)}"
            update_progress(job_id, 100, error=error_msg)  # Mark as complete with error
            scraping_jobs[job_id]['status'] = 'error'
            return
        
        # Start with minimal search parameters to ensure we get results
        search_params = {
            'part': 'snippet',
            'maxResults': 25,
            'type': 'channel'
        }
        
        # Add search query if provided
        if query and query.strip():
            search_params['q'] = query.strip()
            # Use relevance when we have a query
            search_params['order'] = 'relevance'
        else:
            # Use viewCount for popular channels if no query
            search_params['order'] = 'viewCount'
        
        # Only add the most essential filters to avoid over-filtering
        # Add region code (country) if specified and valid
        if location and location.strip() and location != "Worldwide" and location != "Any":
            # Convert from full name to code if needed
            if location in LOCATIONS and LOCATIONS[location]:
                search_params['regionCode'] = LOCATIONS[location]
            # Otherwise use as is if it looks like a country code
            elif len(location) == 2 and location.isalpha():
                search_params['regionCode'] = location.upper()
                
        # Add language if specified and valid
        if language and language.strip() and language != "Any Language" and language != "Any":
            # Convert from full name to code if needed
            if language in LANGUAGES and LANGUAGES[language]:
                search_params['relevanceLanguage'] = LANGUAGES[language]
            # Otherwise use as is if it looks like a language code
            elif len(language) == 2 and language.isalpha():
                search_params['relevanceLanguage'] = language.lower()
        
        print(f"Final search parameters: {search_params}")
        update_progress(job_id, 15)  # 15% progress after setting up parameters
        
        # Search for channels
        next_page_token = None
        total_processed = 0
        
        # Limit max results to save quota
        if not max_results or int(max_results) <= 0:
            max_results = 50
        target_results = min(int(max_results), 100)  # Increased cap from 50 to 100
        
        # Try a search with just the minimal parameters first
        try:
            print("Making initial search request...")
            update_progress(job_id, 20)  # 20% progress before first API call
            
            # Execute the search with retries and proxy rotation
            def make_initial_search():
                return youtube.search().list(**search_params).execute()
                
            search_response = execute_with_retry(make_initial_search)
            update_progress(job_id, 25)  # 25% progress after first successful API call
            
            if 'items' not in search_response or not search_response['items']:
                print("No results found with search parameters")
                scraping_jobs[job_id]['status'] = 'error'
                update_progress(job_id, 100, error="No channels match your search criteria. Try broadening your search.")
                return
            else:
                print(f"Initial search found {len(search_response['items'])} items")
                update_progress(job_id, 30, total_items=target_results, found_items=len(search_response['items']))
        except googleapiclient.errors.HttpError as e:
            error_content = json.loads(e.content.decode())
            error_message = error_content.get('error', {}).get('message', str(e))
            print(f"Initial search error: {error_message}")
            
            # Try to recover with a new proxy if this is a network error
            if "Network Error" in str(e) or "connection" in str(e).lower() or "timeout" in str(e).lower():
                try:
                    print("Network error detected, attempting to use a different proxy...")
                    youtube, new_proxy = initialize_youtube_client(api_key, use_proxy=True)
                    update_progress(job_id, 30, current_proxy=new_proxy)
                    
                    # Try the search again with the new proxy
                    def retry_initial_search():
                        return youtube.search().list(**search_params).execute()
                    
                    search_response = execute_with_retry(retry_initial_search)
                    
                    if 'items' not in search_response or not search_response['items']:
                        update_progress(job_id, 100, error="No channels match your search criteria after retry with new proxy.")
                        scraping_jobs[job_id]['status'] = 'error'
                        return
                    print(f"Retry successful! Found {len(search_response['items'])} items with new proxy")
                    update_progress(job_id, 35, total_items=target_results, found_items=len(search_response['items']))
                except Exception as retry_e:
                    update_progress(job_id, 100, error=f"YouTube API error: {error_message}. Retry with new proxy also failed.")
                    scraping_jobs[job_id]['status'] = 'error'
                    return
            else:
                update_progress(job_id, 100, error=f"YouTube API error: {error_message}")
                scraping_jobs[job_id]['status'] = 'error'
                return
        except Exception as e:
            print(f"Unexpected error on initial search: {str(e)}")
            update_progress(job_id, 100, error=f"Error during search: {str(e)}")
            scraping_jobs[job_id]['status'] = 'error'
            return
        
        # Calculate how much progress to allocate for each batch
        # We'll reserve 25% at the start and 10% at the end, leaving 65% for processing
        progress_per_item = 65.0 / target_results if target_results > 0 else 65.0
        
        # Main search loop
        while total_processed < target_results:
            if next_page_token:
                search_params['pageToken'] = next_page_token
            
            try:
                # Execute the search with retry and proxy rotation
                def make_search():
                    return youtube.search().list(**search_params).execute()
                
                search_response = execute_with_retry(make_search)
                
                # Check if we have items in the response
                if 'items' not in search_response or not search_response['items']:
                    print(f"No more items found in search response")
                    break
                    
                channel_ids = [item['snippet']['channelId'] for item in search_response['items']]
                print(f"Found {len(channel_ids)} channel IDs")
                
                if not channel_ids:
                    break
                
                # Get channel details in batches to optimize API calls
                for i in range(0, len(channel_ids), 5):
                    batch_ids = channel_ids[i:i+5]
                    try:
                        # Get channel details with retry
                        def get_channel_details():
                            return youtube.channels().list(
                                part="snippet,statistics,contentDetails",
                                id=','.join(batch_ids)
                            ).execute()
                        
                        channel_response = execute_with_retry(get_channel_details)
                        
                        if 'items' in channel_response:
                            print(f"Got details for {len(channel_response['items'])} channels")
                            for channel in channel_response['items']:
                                try:
                                    # Check if statistics are available
                                    if 'statistics' not in channel:
                                        print(f"No statistics for channel {channel['id']}")
                                        continue
                                    
                                    # Get subscriber count if available
                                    subscriber_count = 0
                                    if 'subscriberCount' in channel['statistics']:
                                        subscriber_count = int(channel['statistics']['subscriberCount'])
                                    
                                    # Apply subscriber filters only if values are provided and valid
                                    if min_subs and min_subs.isdigit() and subscriber_count > 0 and subscriber_count < int(min_subs):
                                        continue
                                    
                                    if max_subs and max_subs.isdigit() and subscriber_count > int(max_subs):
                                        continue
                                    
                                    # Skip channels with no videos only if they have stats
                                    if 'videoCount' in channel['statistics']:
                                        video_count = int(channel['statistics']['videoCount'])
                                        if video_count == 0:
                                            continue
                                    else:
                                        video_count = 0
                                        
                                    # Get a better thumbnail if available
                                    thumbnail_url = ''
                                    if 'thumbnails' in channel['snippet']:
                                        thumbnails = channel['snippet']['thumbnails']
                                        if 'medium' in thumbnails:
                                            thumbnail_url = thumbnails['medium']['url']
                                        elif 'default' in thumbnails:
                                            thumbnail_url = thumbnails['default']['url']
                                        
                                    # Format the description to be more readable
                                    description = channel['snippet'].get('description', '')
                                    if len(description) > 100:
                                        description = description[:100] + '...'
                                        
                                    channel_data = {
                                        'id': channel['id'],
                                        'title': channel['snippet']['title'],
                                        'description': description,
                                        'subscribers': subscriber_count,
                                        'views': int(channel['statistics'].get('viewCount', 0)),
                                        'videos': video_count,
                                        'country': channel['snippet'].get('country', 'Unknown'),
                                        'created_at': channel['snippet']['publishedAt'],
                                        'thumbnail_url': thumbnail_url,
                                        'banner_url': ''  # YouTube API requires separate call for banner
                                    }
                                    results.append(channel_data)
                                    print(f"Added channel: {channel_data['title']} (ID: {channel_data['id']})")
                                    
                                    # Update partial results immediately
                                    scraping_jobs[job_id]['partial_results'] = results
                                    
                                except Exception as e:
                                    print(f"Error processing channel {channel.get('id')}: {str(e)}")
                        else:
                            print("No items in channel response")
                    except googleapiclient.errors.HttpError as e:
                        error_content = json.loads(e.content.decode())
                        error_message = error_content.get('error', {}).get('message', str(e))
                        
                        # If quota exceeded, stop immediately
                        if "quota" in error_message.lower():
                            update_progress(job_id, 100, error="YouTube API quota exceeded. Please try again tomorrow or use a different API key.")
                            scraping_jobs[job_id]['status'] = 'error'
                            return
                        
                        # For network errors, try with a new proxy
                        if "Network Error" in str(e) or "connection" in str(e).lower() or "timeout" in str(e).lower():
                            try:
                                print("Network error detected during batch processing, trying with a new proxy...")
                                youtube, new_proxy = initialize_youtube_client(api_key, use_proxy=True)
                                update_progress(job_id, scraping_jobs[job_id]['progress'], current_proxy=new_proxy)
                                # Continue with the next batch rather than retrying this one
                            except Exception as proxy_e:
                                print(f"Error switching proxy: {str(proxy_e)}")
                            
                        print(f"HTTP error fetching channel details: {error_message}")
                        # Continue with next batch instead of failing entirely
                        continue
                    except Exception as e:
                        print(f"Error fetching channel details: {str(e)}")
                        continue
                    
                    # Add delay between batches to avoid hitting rate limits
                    time.sleep(1)
                
                total_processed += len(search_response['items'])
                # Calculate progress based on how many items we've processed
                current_progress = 30 + min(total_processed * progress_per_item, 65)
                update_progress(job_id, current_progress, total_items=target_results, found_items=total_processed)
                
                next_page_token = search_response.get('nextPageToken')
                if not next_page_token:
                    print("No next page token, search complete")
                    break
                    
                # Sleep to avoid API rate limits
                time.sleep(1)
                
            except googleapiclient.errors.HttpError as e:
                error_content = json.loads(e.content.decode())
                error_message = error_content.get('error', {}).get('message', str(e))
                
                # Handle quota exceeded error specifically
                if "quota" in error_message.lower():
                    update_progress(job_id, 100, error="YouTube API quota exceeded. Please try again tomorrow or use a different API key.")
                    scraping_jobs[job_id]['status'] = 'error'
                    return
                
                # For network errors, try with a new proxy
                if "Network Error" in str(e) or "connection" in str(e).lower() or "timeout" in str(e).lower():
                    try:
                        print("Network error detected during search, trying with a new proxy...")
                        youtube, new_proxy = initialize_youtube_client(api_key, use_proxy=True)
                        update_progress(job_id, scraping_jobs[job_id]['progress'], current_proxy=new_proxy)
                        # Continue with the loop
                        continue
                    except Exception as proxy_e:
                        print(f"Error switching proxy: {str(proxy_e)}")
                
                update_progress(job_id, scraping_jobs[job_id]['progress'], error=f"YouTube API error: {error_message}")
                
                # For other errors, try to continue with next page
                print(f"HTTP error during search: {error_message}")
                time.sleep(2)
                continue
            except Exception as e:
                print(f"Error during search: {str(e)}")
                time.sleep(1)
                continue
        
        # Final processing - exporting results
        update_progress(job_id, 90, total_items=target_results, found_items=total_processed)
        
        # Save results to session and update job status
        scraping_jobs[job_id]['results'] = results
        scraping_jobs[job_id]['status'] = 'completed'
        
        # If no results but no error, set a message
        if not results and not scraping_jobs[job_id]['error']:
            update_progress(job_id, 100, error="No channels found matching your criteria. Try broadening your search.")
            print("Search completed with 0 results")
        else:
            print(f"Search completed with {len(results)} results")
        
        # Export to Excel for later download if we have results
        if results:
            try:
                export_to_files(job_id, results)
                print(f"Successfully exported {len(results)} channels to files")
                update_progress(job_id, 100)  # 100% progress after export
            except Exception as e:
                print(f"Error exporting to files: {str(e)}")
                update_progress(job_id, 100, error=f"Search completed but error exporting files: {str(e)}")
        else:
            update_progress(job_id, 100)  # 100% progress even with no results
            
    except Exception as e:
        print(f"Unexpected error in search function: {str(e)}")
        update_progress(job_id, 100, error=str(e))
        scraping_jobs[job_id]['status'] = 'error'


def export_to_files(job_id, results):
    """Export results to various file formats"""
    if not results:
        return
        
    # Create DataFrame
    df = pd.DataFrame(results)
    
    # Reorder columns
    df = df[['title', 'subscribers', 'views', 'videos', 'country', 'created_at', 'id', 'description']]
    
    # Rename columns
    df.columns = ["Channel", "Subscribers", "Views", "Videos", "Country", "Created", "Channel ID", "Description"]
    
    # Save to Excel
    excel_path = os.path.join(app.config['UPLOAD_FOLDER'], f'youtube_channels_{job_id}.xlsx')
    df.to_excel(excel_path, index=False)
    scraping_jobs[job_id]['excel_file'] = excel_path
    
    # Save to CSV
    csv_path = os.path.join(app.config['UPLOAD_FOLDER'], f'youtube_channels_{job_id}.csv')
    df.to_csv(csv_path, index=False)
    scraping_jobs[job_id]['csv_file'] = csv_path
    
    # Save to JSON
    json_path = os.path.join(app.config['UPLOAD_FOLDER'], f'youtube_channels_{job_id}.json')
    with open(json_path, 'w', encoding='utf-8') as f:
        json.dump(results, f, ensure_ascii=False, indent=4)
    scraping_jobs[job_id]['json_file'] = json_path


def test_youtube_api_key(api_key):
    """Test a YouTube API key and get quota information"""
    try:
        print(f"Testing API key: {api_key[:5]}...")  # Only show first few characters for security
        
        if not api_key:
            print("API key is empty")
            return {
                "success": False,
                "message": "API key cannot be empty"
            }
            
        youtube = googleapiclient.discovery.build(
            API_SERVICE_NAME, API_VERSION, developerKey=api_key, cache_discovery=False)
        
        # Make a simple request to validate the key
        print("Making test request to YouTube API...")
        response = youtube.channels().list(
            part="snippet",
            id="UC_x5XG1OV2P6uZZ5FSM9Ttw"  # Google Developers channel
        ).execute()
        
        # Check if we got a valid response
        if 'items' in response and len(response['items']) > 0:
            print("API key is valid - got successful response")
            # If we get here, the key is valid, but we don't get quota info directly
            # In a real app, you'd need to track usage on your own or use the Google Cloud Console
            
            # Return mock quota info for demonstration
            return {
                "success": True,
                "message": "API key is valid and working correctly",
                "quota_info": {
                    "limit": "10,000 units/day",
                    "used": "~1,000 units",
                    "remaining": "~9,000 units"
                }
            }
        else:
            print("API key returned empty response")
            return {
                "success": False,
                "message": "API key validation failed: Empty response"
            }
    except googleapiclient.errors.HttpError as e:
        error_content = json.loads(e.content.decode())
        error_message = error_content.get('error', {}).get('message', "Unknown error")
        
        print(f"API key error: {error_message}")
        
        if "API key" in error_message:
            return {
                "success": False,
                "message": f"Invalid API key: {error_message}"
            }
        elif "quota" in error_message.lower():
            return {
                "success": False,
                "message": "API key has exceeded its quota limits"
            }
        else:
            return {
                "success": False,
                "message": f"API error: {error_message}"
            }
    except Exception as e:
        print(f"Unexpected error testing API key: {str(e)}")
        return {
            "success": False,
            "message": f"Error testing API key: {str(e)}"
        }


@app.route('/')
def index():
    return render_template('single_page.html', 
                          categories=CATEGORIES.keys(), 
                          locations=LOCATIONS.keys(),
                          languages=LANGUAGES.keys())


@app.route('/single-page')
def single_page():
    # New single-page route that includes all functionality
    return render_template('single_page.html', 
                          categories=CATEGORIES.keys(), 
                          locations=LOCATIONS.keys(),
                          languages=LANGUAGES.keys())


@app.route('/test-api-key', methods=['POST'])
def test_api_key():
    data = request.json
    api_key = data.get('api_key', '').strip()
    
    if not api_key:
        return jsonify({
            "success": False,
            "message": "Please provide an API key to test"
        })
    
    result = test_youtube_api_key(api_key)
    return jsonify(result)


@app.route('/scrape', methods=['POST'])
def scrape():
    # Get form data
    min_subs = request.form.get('min_subs', '')
    max_subs = request.form.get('max_subs', '')
    category = request.form.get('category', 'All')
    location = request.form.get('location', 'Worldwide')
    language = request.form.get('language', 'Any Language')
    upload_frequency = request.form.get('upload_frequency', 'Any')
    api_key = request.form.get('api_key', '').strip() or DEFAULT_API_KEY
    max_results = request.form.get('max_results', 50)
    query = request.form.get('query', '')
    
    try:
        max_results = int(max_results)
    except:
        max_results = 50
    
    # Validate inputs
    if min_subs and not min_subs.isdigit():
        return jsonify({'error': 'Minimum subscribers must be a number'}), 400
        
    if max_subs and not max_subs.isdigit():
        return jsonify({'error': 'Maximum subscribers must be a number'}), 400
    
    # Create job ID
    job_id = str(int(time.time()))
    
    # Initialize job status
    scraping_jobs[job_id] = {
        'status': 'started',
        'progress': 0,
        'results': [],
        'partial_results': [],
        'error': None,
        'excel_file': None,
        'csv_file': None,
        'json_file': None
    }
    
    # Start scraping in a background thread
    thread = threading.Thread(
        target=scrape_youtube_channels,
        kwargs={
            'job_id': job_id,
            'min_subs': min_subs,
            'max_subs': max_subs,
            'category': category,
            'location': location,
            'language': language,
            'upload_frequency': upload_frequency,
            'api_key': api_key,
            'max_results': max_results,
            'query': query
        }
    )
    thread.daemon = True
    thread.start()
    
    return jsonify({'job_id': job_id})


@app.route('/status/<job_id>')
def status(job_id):
    if job_id not in scraping_jobs:
        return jsonify({'error': 'Job not found'}), 404
    
    job = scraping_jobs[job_id]
    
    # Create response with partial results for live updates
    response = {
        'status': job['status'],
        'progress': job['progress'],
        'error': job['error'],
        'result_count': len(job['results'] or job['partial_results']),
        'has_excel': job['excel_file'] is not None,
        'has_csv': job['csv_file'] is not None,
        'has_json': job['json_file'] is not None,
        'current_proxy': job.get('current_proxy', 'None'),
        'proxies_enabled': PROXIES_ENABLED
    }
    
    # Add status message based on current status
    if job['status'] == 'starting':
        response['status_message'] = 'Preparing to start search...'
    elif job['status'] == 'verifying_api':
        response['status_message'] = 'Verifying YouTube API connection...'
    elif job['status'] == 'connection_established':
        response['status_message'] = 'Connection established! Preparing search...'
    elif job['status'] == 'running':
        # Include proxy info in status message
        proxy_info = f" (via proxy: {job.get('current_proxy', 'None')})" if PROXIES_ENABLED and job.get('current_proxy') else ""
        response['status_message'] = f"Searching for channels... Found {len(job['partial_results'])} so far{proxy_info}"
    elif job['status'] == 'completed':
        response['status_message'] = f"Search completed! Found {len(job['results'])} channels"
    elif job['status'] == 'error':
        response['status_message'] = f"Error: {job['error']}"
    
    # Add partial results for live updates if requested
    if request.args.get('include_partial') == 'true' and job['partial_results']:
        response['partial_results'] = job['partial_results']
    
    return jsonify(response)


@app.route('/proxy-status')
def proxy_status():
    """Get information about the proxies currently in use"""
    return jsonify({
        'enabled': PROXIES_ENABLED,
        'total_proxies': len(PROXY_LIST),
        'current_index': CURRENT_PROXY_INDEX,
        'proxies': PROXY_LIST if request.args.get('include_list') == 'true' else []
    })


@app.route('/toggle-proxies', methods=['POST'])
def toggle_proxies():
    """Enable or disable proxy rotation"""
    global PROXIES_ENABLED, PROXY_LIST
    data = request.json
    
    if 'enabled' in data:
        PROXIES_ENABLED = bool(data['enabled'])
        
        # If enabling proxies or explicitly requesting refresh, refresh the list
        if (PROXIES_ENABLED and not PROXY_LIST) or data.get('refresh', False):
            PROXY_LIST = fetch_free_proxies()
            
        return jsonify({
            'success': True,
            'enabled': PROXIES_ENABLED,
            'total_proxies': len(PROXY_LIST)
        })
    
    return jsonify({'success': False, 'error': 'Missing enabled parameter'}), 400


@app.route('/results/<job_id>')
def results(job_id):
    if job_id not in scraping_jobs:
        flash('Job not found or expired', 'danger')
        return redirect(url_for('index'))
    
    job = scraping_jobs[job_id]
    error = job['error']
    
    # Set default values for search_initiated flag
    search_initiated = job['status'] != 'starting' and job['status'] != 'waiting'
    
    # Get page for pagination
    page = request.args.get('page', 1, type=int)
    per_page = 12  # Number of channels per page
    
    # Calculate pagination
    channels = job['results'] or []
    total_channels = len(channels)
    total_pages = (total_channels + per_page - 1) // per_page if total_channels > 0 else 1
    
    # Get channels for current page
    start_idx = (page - 1) * per_page
    end_idx = min(start_idx + per_page, total_channels)
    page_channels = channels[start_idx:end_idx] if total_channels > 0 else []
    
    return render_template(
        'results.html', 
        job_id=job_id, 
        results=page_channels, 
        count=total_channels,
        page=page, 
        pages=total_pages, 
        per_page=per_page,
        error=error,
        search_initiated=search_initiated
    )


@app.route('/download/<job_id>')
def download(job_id):
    if job_id not in scraping_jobs:
        return redirect(url_for('index'))
    
    job = scraping_jobs[job_id]
    format_type = request.args.get('format', 'excel').lower()
    
    if format_type == 'excel' and job['excel_file']:
        file_path = job['excel_file']
        mimetype = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
        download_name = f'youtube_channels_{job_id}.xlsx'
    elif format_type == 'csv' and job['csv_file']:
        file_path = job['csv_file']
        mimetype = 'text/csv'
        download_name = f'youtube_channels_{job_id}.csv'
    elif format_type == 'json' and job['json_file']:
        file_path = job['json_file']
        mimetype = 'application/json'
        download_name = f'youtube_channels_{job_id}.json'
    else:
        return redirect(url_for('results', job_id=job_id))
    
    if not os.path.exists(file_path):
        return redirect(url_for('results', job_id=job_id))
    
    return send_file(file_path, 
                    mimetype=mimetype,
                    as_attachment=True,
                    download_name=download_name)


# Add a new endpoint for API documentation
@app.route('/api-docs')
def api_docs():
    return render_template('api_docs.html')


@app.route('/api/search', methods=['POST'])
def api_search():
    """API endpoint for search that returns a job ID instead of redirecting"""
    # Get form data
    data = request.json
    
    # Print received data for debugging
    print(f"Received search request with data: {data}")
    
    # Handle form inputs with defaults
    min_subs = data.get('min_subs', '')
    max_subs = data.get('max_subs', '')
    category = data.get('category', '')
    location = data.get('location', '')
    language = data.get('language', '')
    upload_frequency = data.get('upload_frequency', '')
    api_key = data.get('api_key', '').strip() or DEFAULT_API_KEY
    query = data.get('query', '')
    
    # Handle max_results specially - ensure it's a valid number
    try:
        max_results = int(data.get('max_results', 50))
        if max_results <= 0:
            max_results = 50
    except (ValueError, TypeError):
        max_results = 50
    
    print(f"Processing search with parameters: query={query}, min_subs={min_subs}, max_subs={max_subs}, category={category}, location={location}, language={language}, max_results={max_results}")
    
    # Create job ID
    job_id = str(int(time.time()))
    
    # Initialize job status
    scraping_jobs[job_id] = {
        'status': 'starting',
        'progress': 0,
        'results': [],
        'partial_results': [],
        'error': None,
        'excel_file': None,
        'csv_file': None,
        'json_file': None,
        'params': {
            'min_subs': min_subs,
            'max_subs': max_subs,
            'category': category,
            'location': location,
            'language': language,
            'upload_frequency': upload_frequency,
            'api_key': api_key,
            'max_results': max_results,
            'query': query
        }
    }
    
    # Start the search immediately in a background thread
    thread = threading.Thread(
        target=verify_and_search,
        kwargs={
            'job_id': job_id,
            'min_subs': min_subs,
            'max_subs': max_subs,
            'category': category,
            'location': location,
            'language': language,
            'upload_frequency': upload_frequency,
            'api_key': api_key,
            'max_results': max_results,
            'query': query
        }
    )
    thread.daemon = True
    thread.start()
    
    # Return the job ID for client-side tracking
    return jsonify({'job_id': job_id, 'success': True})


@app.route('/start-search/<job_id>', methods=['POST'])
def start_search(job_id):
    if job_id not in scraping_jobs:
        return jsonify({'success': False, 'error': 'Job not found'}), 404
    
    job = scraping_jobs[job_id]
    
    # Only start if in waiting status
    if job['status'] != 'waiting':
        return jsonify({'success': False, 'error': 'Search already in progress or completed'}), 400
    
    # Get parameters from saved job
    params = job['params']
    
    # Update job status to starting
    scraping_jobs[job_id]['status'] = 'starting'
    
    # First verify API key and establish connection before searching
    thread = threading.Thread(
        target=verify_and_search,
        kwargs={
            'job_id': job_id,
            **params
        }
    )
    thread.daemon = True
    thread.start()
    
    return jsonify({'success': True})


def verify_and_search(job_id, **kwargs):
    """First verify API connection, then start searching if successful"""
    api_key = kwargs.get('api_key', '')
    
    # Update job status
    scraping_jobs[job_id]['status'] = 'verifying_api'
    scraping_jobs[job_id]['progress'] = 5
    
    try:
        # Test the API key
        print(f"Verifying API key before starting search...")
        # Add small delay to show loading animation
        time.sleep(1.5)
        
        result = test_youtube_api_key(api_key)
        
        if not result['success']:
            # API key invalid or quota exceeded
            scraping_jobs[job_id]['status'] = 'error'
            scraping_jobs[job_id]['error'] = f"API Error: {result['message']}"
            return
        
        # API key is valid, update status and start search
        scraping_jobs[job_id]['progress'] = 10
        scraping_jobs[job_id]['status'] = 'connection_established'
        print(f"API verification successful. Starting search...")
        
        # Brief pause to show the connection established status
        time.sleep(2)
        
        # Update to searching status
        scraping_jobs[job_id]['status'] = 'running'
        
        # Now start the actual search
        scrape_youtube_channels(job_id=job_id, **kwargs)
        
    except Exception as e:
        scraping_jobs[job_id]['status'] = 'error'
        scraping_jobs[job_id]['error'] = f"Error during API verification: {str(e)}"
        print(f"Error during API verification: {str(e)}")


# Format number filter for templates
@app.template_filter('format_number')
def format_number(value):
    if value is None:
        return "0"
    
    try:
        if value >= 1000000:
            return f"{value/1000000:.1f}M"
        elif value >= 1000:
            return f"{value/1000:.1f}K"
        else:
            return str(value)
    except:
        return str(value)


@app.route('/search', methods=['POST'])
def search():
    # Get form data
    min_subs = request.form.get('min_subs', '')
    max_subs = request.form.get('max_subs', '')
    category = request.form.get('category', '')
    location = request.form.get('location', '')
    language = request.form.get('language', '')
    upload_frequency = request.form.get('upload_frequency', '')
    api_key = request.form.get('api_key', '').strip() or DEFAULT_API_KEY
    max_results = request.form.get('max_results', 50)
    query = request.form.get('query', '')
    
    try:
        max_results = int(max_results)
    except:
        max_results = 50
    
    # Create job ID
    job_id = str(int(time.time()))
    
    # Initialize job status - set to starting and immediately begin search
    scraping_jobs[job_id] = {
        'status': 'starting',
        'progress': 0,
        'results': [],
        'partial_results': [],
        'error': None,
        'excel_file': None,
        'csv_file': None,
        'json_file': None,
        'params': {
            'min_subs': min_subs,
            'max_subs': max_subs,
            'category': category,
            'location': location,
            'language': language,
            'upload_frequency': upload_frequency,
            'api_key': api_key,
            'max_results': max_results,
            'query': query
        }
    }
    
    # Start the search immediately in a background thread
    thread = threading.Thread(
        target=verify_and_search,
        kwargs={
            'job_id': job_id,
            'min_subs': min_subs,
            'max_subs': max_subs,
            'category': category,
            'location': location,
            'language': language,
            'upload_frequency': upload_frequency,
            'api_key': api_key,
            'max_results': max_results,
            'query': query
        }
    )
    thread.daemon = True
    thread.start()
    
    # Redirect to results page - search is already started
    return redirect(url_for('results', job_id=job_id))


@app.route('/api/results/<job_id>')
def api_results(job_id):
    """API endpoint to get results for a job"""
    if job_id not in scraping_jobs:
        return jsonify({'error': 'Job not found', 'success': False}), 404
    
    job = scraping_jobs[job_id]
    
    # Get page for pagination
    page = request.args.get('page', 1, type=int)
    per_page = request.args.get('per_page', 12, type=int)
    
    # Calculate pagination
    channels = job['results'] or []
    total_channels = len(channels)
    total_pages = (total_channels + per_page - 1) // per_page if total_channels > 0 else 1
    
    # Get channels for current page
    start_idx = (page - 1) * per_page
    end_idx = min(start_idx + per_page, total_channels)
    page_channels = channels[start_idx:end_idx] if total_channels > 0 else []
    
    return jsonify({
        'success': True,
        'job_id': job_id,
        'results': page_channels,
        'count': total_channels,
        'page': page,
        'pages': total_pages,
        'per_page': per_page,
        'error': job['error'],
        'status': job['status'],
        'progress': job['progress'],
        'has_excel': job['excel_file'] is not None,
        'has_csv': job['csv_file'] is not None,
        'has_json': job['json_file'] is not None
    })


if __name__ == '__main__':
    app.run(debug=True) 